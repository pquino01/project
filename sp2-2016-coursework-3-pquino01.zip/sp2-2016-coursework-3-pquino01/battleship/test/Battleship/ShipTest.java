package Battleship;

import junit.framework.TestCase;
import org.junit.Test;

/**
 * Test class to test methods from class Ship
 *
 * @author Pablo Quinoa
 */
public class ShipTest extends TestCase {

    public ShipTest(String testName) {
        super(testName);
    }

    /**
     * Test of Ocean constructor, of class Ship.
     */
    @Test
    public void testShipConstructor_shipLength() {
        Ship instance = new Battleship();
        int expResult = 4;
        int result = instance.getLength();
        assertEquals("length of a new ship of type battleship", expResult, result);
    }

    /**
     * Test of Ocean constructor, of class Ship.
     */
    @Test
    public void testShipConstructor_hitArray() {
        Ship instance = new Battleship();
        int countNotHit = 0;
        for (int i = 0; i < instance.getLength(); i++) {
            if (instance.getHit()[i] == false) {
                countNotHit++;
            }
        }
        int expResult = 4;
        int result = countNotHit;
        assertEquals("number of non hit positions after creating a battleship", expResult, result);
    }

    /**
     * Test of getShipType method, of class Ship.
     */
    @Test
    public void testGetShipType_emptySea() {
        Ship instance = new EmptySea();
        String expResult = "EmptySea";
        String result = instance.getShipType();
        assertEquals("getShipType after creating an empty sea", expResult, result);
    }

    /**
     * Test of getShipType method, of class Ship.
     */
    @Test
    public void testGetShipType_battleship() {
        Ship instance = new Battleship();
        String expResult = "Battleship";
        String result = instance.getShipType();
        assertEquals("getShipType after creating a battleship", expResult, result);
    }

    /**
     * Test of getShipType method, of class Ship.
     */
    @Test
    public void testGetShipType_cruiser() {
        Ship instance = new Cruiser();
        String expResult = "Cruiser";
        String result = instance.getShipType();
        assertEquals("getShipType after creating a cruiser", expResult, result);
    }

    /**
     * Test of getShipType method, of class Ship.
     */
    @Test
    public void testGetShipType_destroyer() {
        Ship instance = new Destroyer();
        String expResult = "Destroyer";
        String result = instance.getShipType();
        assertEquals("getShipType after creating a destroyer", expResult, result);
    }

    /**
     * Test of getShipType method, of class Ship.
     */
    @Test
    public void testGetShipType_submarine() {
        Ship instance = new Submarine();
        String expResult = "Submarine";
        String result = instance.getShipType();
        assertEquals("getShipType after creating a submarine", expResult, result);
    }

    /**
     * Test of shootAt method, of class Ship.
     */
    @Test
    public void testShootAt_emptySea() {
        int row = 0;
        int column = 0;
        Ship instance = new EmptySea();
        instance.setBowRow(row);
        instance.setBowColumn(column);
        boolean expResult = false;
        boolean result = instance.shootAt(row, column);
        assertEquals("shoot at an empty sea", expResult, result);
    }

    /**
     * Test of shootAt method, of class Ship.
     */
    @Test
    public void testShootAt_battleship() {
        int row = 0;
        int column = 0;
        Ship instance = new Battleship();
        instance.setBowRow(row);
        instance.setBowColumn(column);
        instance.setHorizontal(true);
        boolean expResult = true;
        boolean result = instance.shootAt(0, 1);
        assertEquals("shoot at a certain position where a battleship (real ship) is located", expResult, result);

    }

    /**
     * Test of getShipType method, of class Ship.
     */
    @Test
    public void testIsRealShip_emptySea() {
        Ship instance = new EmptySea();
        Boolean expResult = false;
        Boolean result = instance.isRealShip();
        assertEquals("isRealShip an empty sea?", expResult, result);
    }

    /**
     * Test of getShipType method, of class Ship.
     */
    @Test
    public void testIsRealShip_battleship() {
        Ship instance = new Battleship();
        Boolean expResult = true;
        Boolean result = instance.isRealShip();
        assertEquals("isRealShip a battleship?", expResult, result);
    }

    /**
     * Test of getShipType method, of class Ship.
     */
    @Test
    public void testIsRealShip_cruiser() {
        Ship instance = new Cruiser();
        Boolean expResult = true;
        Boolean result = instance.isRealShip();
        assertEquals("isRealShip a cruiser?", expResult, result);
    }

    /**
     * Test of getShipType method, of class Ship.
     */
    @Test
    public void testIsRealShip_destroyer() {
        Ship instance = new Destroyer();
        Boolean expResult = true;
        Boolean result = instance.isRealShip();
        assertEquals("isRealShip a destroyer?", expResult, result);
    }

    /**
     * Test of getShipType method, of class Ship.
     */
    @Test
    public void testIsRealShip_submarine() {
        Ship instance = new Submarine();
        Boolean expResult = true;
        Boolean result = instance.isRealShip();
        assertEquals("isRealShip a submarine?", expResult, result);
    }

    /**
     * Test of isSunk method, of class Ship.
     */
    @Test
    public void testIsSunk_allPartsShipShot() {
        //checking sunk ship
        int row = 0;
        int column = 0;
        Ship instance = new Cruiser();
        instance.setBowRow(row);
        instance.setBowColumn(column);
        instance.setHorizontal(true);
        instance.shootAt(0, 0);
        instance.shootAt(0, 1);
        instance.shootAt(0, 2);
        boolean expResult = true;
        boolean result = instance.isSunk();
        assertEquals("all parts of the ship shot (sunk)", expResult, result);
    }

    /**
     * Test of isSunk method, of class Ship.
     */
    @Test
    public void testIsSunk_onlyHalfShipShot() {
        //checking not sunk ship (only 1/2 of the ship shot)
        int row = 0;
        int column = 0;
        Ship instance = new Destroyer();
        instance.setBowRow(row);
        instance.setBowColumn(column);
        instance.setHorizontal(true);
        instance.shootAt(0, 0);
        boolean expResult = false;
        boolean result = instance.isSunk();
        assertEquals("only bow shot (1/2 of the Destroyer shot)", expResult, result);
    }

    /**
     * Test of partOfTheShip method, of class Ship.
     */
    public void testPartOfTheShip() {
        int row = 0;
        int column = 0;
        Ship instance = new Cruiser();
        instance.setBowRow(row);
        instance.setBowColumn(column);
        instance.setHorizontal(true);
        int expResult = 2;
        int result = instance.partOfTheShip(0, 2);
        assertEquals("partOfTheShip pointing at row/column where the last position of cruiser is (2)", expResult, result);
    }

    /**
     * Test of partOfTheShip method, of class Ship.
     */
    @Test(expected = ArrayIndexOutOfBoundsException.class)
    public void testPartOfTheShip_positionOutsideShip() {
        int row = 0;
        int column = 0;
        Ship instance = new Cruiser();
        instance.setBowRow(row);
        instance.setBowColumn(column);
        instance.setHorizontal(true);
        //trying to access a position outside of the ship array
        instance.partOfTheShip(0, 3);
    }

}
