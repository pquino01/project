package Battleship;

import junit.framework.TestCase;
import static junit.framework.TestCase.assertEquals;
import org.junit.Test;

/**
 * Test class to test methods from class Ocean
 *
 * @author Pablo Quinoa
 */
public class OceanTest extends TestCase {

    public OceanTest(String testName) {
        super(testName);
    }

    /**
     * Test of Ocean constructor, of class Ship.
     */
    @Test
    public void testOceanConstructor_allEmptySeaShips() {
        Ocean instance = new Ocean();
        int emptySeaCount = 0;
        for (int row = 0; row < 10; row++) {
            for (int column = 0; column < 10; column++) {
                if (instance.getShipArray()[row][column].getShipType().equals("EmptySea")) {
                    emptySeaCount++;
                }
            }
        }
        int expResult = 100;
        int result = emptySeaCount;
        assertEquals("number of emptySea ships after constructing Ocean", expResult, result);
    }

    /**
     * Test of Ocean constructor, of class Ship.
     */
    @Test
    public void testOceanConstructor_shotsFired() {
        Ocean instance = new Ocean();
        int expResult = 0;
        int result = instance.getShotsFired();
        assertEquals("number of shots fired after constructing Ocean", expResult, result);
    }

    /**
     * Test of Ocean constructor, of class Ship.
     */
    @Test
    public void testOceanConstructor_hitCount() {
        Ocean instance = new Ocean();
        int expResult = 0;
        int result = instance.getHitCount();
        assertEquals("number of hits after constructing Ocean", expResult, result);
    }

    /**
     * Test of Ocean constructor, of class Ship.
     */
    @Test
    public void testOceanConstructor_shipsSunk() {
        Ocean instance = new Ocean();
        int expResult = 0;
        int result = instance.getShipsSunk();
        assertEquals("number of sunk ships after constructing Ocean", expResult, result);
    }

    /**
     * Test of placeAllShipsRandomly method, of class Ocean.
     */
    public void testPlaceAllShipsRandomly_emptySea() {
        Ocean instance = new Ocean();
        instance.placeAllShipsRandomly();
        int countEmptySea = 0;
        for (int row = 0; row < 10; row++) {
            for (int column = 0; column < 10; column++) {
                if (instance.getShipArray()[row][column].getShipType().equals("EmptySea")) {
                    countEmptySea++;
                }
            }
        }
        int expResult = 80;
        int result = countEmptySea;
        assertEquals("number of squares occupied by EmptySea ships after randomly placing all ships", expResult, result);
    }

    /**
     * Test of placeAllShipsRandomly method, of class Ocean.
     */
    public void testPlaceAllShipsRandomly_battleship() {
        Ocean instance = new Ocean();
        instance.placeAllShipsRandomly();
        int countBattleship = 0;
        for (int row = 0; row < 10; row++) {
            for (int column = 0; column < 10; column++) {
                if (instance.getShipArray()[row][column].getShipType().equals("Battleship")) {
                    countBattleship++;
                }
            }
        }
        int expResult = 4;
        int result = countBattleship;
        assertEquals("number of squares occupied by Battleships after randomly placing all ships", expResult, result);
    }

    /**
     * Test of placeAllShipsRandomly method, of class Ocean.
     */
    public void testPlaceAllShipsRandomly_cruiser() {
        Ocean instance = new Ocean();
        instance.placeAllShipsRandomly();
        int countCruiser = 0;
        for (int row = 0; row < 10; row++) {
            for (int column = 0; column < 10; column++) {
                if (instance.getShipArray()[row][column].getShipType().equals("Cruiser")) {
                    countCruiser++;
                }
            }
        }
        int expResult = 6;
        int result = countCruiser;
        assertEquals("number of squares occupied by Cruisers after randomly placing all ships", expResult, result);
    }

    /**
     * Test of placeAllShipsRandomly method, of class Ocean.
     */
    public void testPlaceAllShipsRandomly_destroyer() {
        Ocean instance = new Ocean();
        instance.placeAllShipsRandomly();
        int countDestroyer = 0;
        for (int row = 0; row < 10; row++) {
            for (int column = 0; column < 10; column++) {
                if (instance.getShipArray()[row][column].getShipType().equals("Destroyer")) {
                    countDestroyer++;
                }
            }
        }
        int expResult = 6;
        int result = countDestroyer;
        assertEquals("number of squares occupied by Cruisers after randomly placing all ships", expResult, result);
    }

    /**
     * Test of placeAllShipsRandomly method, of class Ocean.
     */
    public void testPlaceAllShipsRandomly_submarine() {
        Ocean instance = new Ocean();
        instance.placeAllShipsRandomly();
        int countSubmarine = 0;
        for (int row = 0; row < 10; row++) {
            for (int column = 0; column < 10; column++) {
                if (instance.getShipArray()[row][column].getShipType().equals("Submarine")) {
                    countSubmarine++;
                }
            }
        }
        int expResult = 4;
        int result = countSubmarine;
        assertEquals("number of squares occupied by Submarines after randomly placing all ships", expResult, result);
    }

    /**
     * Test of getShipsSunk method, of class Ocean.
     */
    @Test
    public void testGetShipsSunk() {
        Ocean instance = new Ocean();
        instance.placeAllShipsRandomly();
        for (int row = 0; row < 10; row++) {
            for (int column = 0; column < 10; column++) {
                instance.shootAt(row, column);
            }
        }
        int expResult = 10;
        int result = instance.getShipsSunk();
        assertEquals("number of sunk ships after shooting at all ships in Ocean", expResult, result);
    }

    /**
     * Test of getShipArray method, of class Ocean.
     */
    public void testGetShipArray() {
        Ocean instance = new Ocean();
        Ship[][] arrayAux = new Ship[10][10];
        int expResult = arrayAux.length;
        int result = instance.getShipArray().length;
        assertEquals("array of ships after creating new Ocean length", expResult, result);

    }

    /**
     * Test of getShotsFired method, of class Ocean.
     */
    public void testGetShotsFired() {
        Ocean instance = new Ocean();
        instance.shootAt(0, 0);
        instance.shootAt(5, 5);
        int expResult = 2;
        int result = instance.getShotsFired();
        assertEquals("getShotsFired after shooting 2 times", expResult, result);
    }

    /**
     * Test of getHitCount method, of class Ocean.
     */
    public void testGetHitCount() {
        Ocean instance = new Ocean();
        instance.placeAllShipsRandomly();
        for (int row = 0; row < 10; row++) {
            for (int column = 0; column < 10; column++) {
                instance.shootAt(row, column);
            }
        }
        int expResult = 20;
        int result = instance.getHitCount();
        assertEquals("getHitCount after shooting to all squares in Ocean", expResult, result);
    }

    /**
     * Test of isGameOver method, of class Ocean.
     */
    public void testIsGameOver_startOfGame() {
        Ocean instance = new Ocean();
        instance.placeAllShipsRandomly();
        boolean expResult = false;
        boolean result = instance.isGameOver();
        assertEquals("isGameOver after just placed the ships randomly in Ocean (just started game)", expResult, result);
    }

    /**
     * Test of isGameOver method, of class Ocean.
     */
    public void testIsGameOver_endOfGame() {
        Ocean instance = new Ocean();
        instance.placeAllShipsRandomly();
        for (int row = 0; row < 10; row++) {
            for (int column = 0; column < 10; column++) {
                instance.shootAt(row, column);
            }
        }
        boolean expResult = true;
        boolean result = instance.isGameOver();
        assertEquals("isGameOver after shooting at all ships in Ocean", expResult, result);
    }

    /**
     * Test of hasSunkShipAt method, of class Ocean.
     */
    public void testHasSunkShipAt_notSunk() {
        Ocean instance = new Ocean();
        Ship s = new Battleship();
        s.setBowRow(0);
        s.setBowColumn(0);
        s.setHorizontal(true);
        for (int i = 0; i < 4; i++) {
            instance.getShipArray()[0][i] = s;
        }
        instance.shootAt(0, 0);
        boolean expResult = false;
        boolean result = instance.hasSunkShipAt(0, 0);
        assertEquals("hasSunkShipAt after shooting at just the bow of a battleship (1/4 of the ship shot only)", expResult, result);
    }

    /**
     * Test of hasSunkShipAt method, of class Ocean.
     */
    public void testHasSunkShipAt_sunk() {
        Ocean instance = new Ocean();
        Ship s = new Battleship();
        s.setBowRow(0);
        s.setBowColumn(0);
        s.setHorizontal(true);
        for (int i = 0; i < 4; i++) {
            instance.getShipArray()[0][i] = s;
        }
        instance.shootAt(0, 0);
        instance.shootAt(0, 1);
        instance.shootAt(0, 2);
        instance.shootAt(0, 3);
        boolean expResult = true;
        boolean result = instance.hasSunkShipAt(0, 0);
        assertEquals("hasSunkShipAt after shooting at all the ship parts (4/4 of the ship shot)", expResult, result);
    }

    /**
     * Test of getShipTypeAt method, of class Ocean.
     */
    public void testGetShipTypeAt() {
        Ocean instance = new Ocean();
        Ship s = new Submarine();
        s.setBowRow(0);
        s.setBowColumn(0);
        s.setHorizontal(true);
        instance.getShipArray()[0][0] = s;
        String expResult = "Submarine";
        String result = instance.getShipTypeAt(0, 0);
        assertEquals("getShipTypeAt at position where submarine was created", expResult, result);
    }

    /**
     * Test of shootAt method, of class Ocean.
     */
    public void testShootAt_emptySea() {
        Ocean instance = new Ocean();
        boolean expResult = false;
        boolean result = instance.shootAt(0, 0);
        assertEquals("shootAt an emptySea", expResult, result);
    }

    /**
     * Test of shootAt method, of class Ocean.
     */
    public void testShootAt_nonSunkDestroyer() {
        Ocean instance = new Ocean();
        Ship s = new Destroyer();
        s.setBowRow(0);
        s.setBowColumn(0);
        s.setHorizontal(true);
        instance.getShipArray()[0][0] = s;
        instance.getShipArray()[0][1] = s;
        boolean expResult = true;
        boolean result = instance.shootAt(0, 0);
        assertEquals("shootAt a non sunk destroyer postion", expResult, result);
    }

    /**
     * Test of shootAt method, of class Ocean.
     */
    public void testShootAt_sunkDestroyer() {
        Ocean instance = new Ocean();
        Ship s = new Destroyer();
        s.setBowRow(0);
        s.setBowColumn(0);
        s.setHorizontal(true);
        instance.getShipArray()[0][0] = s;
        instance.getShipArray()[0][1] = s;
        instance.shootAt(0, 0);
        instance.shootAt(0, 1);
        boolean expResult = false;
        boolean result = instance.shootAt(0, 0);
        assertEquals("shootAt a sunk ship", expResult, result);
    }

}
