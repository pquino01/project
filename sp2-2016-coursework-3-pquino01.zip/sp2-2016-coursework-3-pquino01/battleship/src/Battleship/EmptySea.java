package Battleship;

/**
 * Subclass of ship representing an empty sea (ship of length 1)
 *
 * @author Pablo Quinoa
 */
public class EmptySea extends Ship {
    
    /**
     * Constant representing the length of a battleship 
     */
    private static final int EMPTYSEA_LENGTH = 1;

    /**
     * Constructs a new Empty Sea and sets length of super class to 1
     */
    public EmptySea() {
        super(EMPTYSEA_LENGTH);
    }

    /**
     * Returns the type of this ship (in this case EmptySea)
     *
     * @return the type of ship
     */
    @Override
    public String getShipType() {
        return "EmptySea";
    }

    /**
     * If a part of the ship occupies the given row and column, and the ship
     * hasn’t been sunk, mark that part of the ship as hit (in the hit array,
     * index 0 indicates the bow) and return true, otherwise return false
     *
     * @param row number to be shot
     * @param column number to be shot
     *
     * @return whether the ship was succesfully hit (real ship not sunk)
     */
    @Override
    public boolean shootAt(int row, int column) {
        return false;
    }

    /**
     * Returns true if every part of the ship has been hit, false otherwise
     *
     * @return wether every part of the ship has been hit or not
     */
    @Override
    public boolean isSunk() {
        return false;
    }

    /**
     * Returns true, to ease development of classes for real ships
     *
     * @return wether is a real ship (empty sea would return false)
     */
    @Override
    public boolean isRealShip() {
        return false;
    }
}
