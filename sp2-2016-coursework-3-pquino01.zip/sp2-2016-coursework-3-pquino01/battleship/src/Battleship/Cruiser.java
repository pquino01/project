package Battleship;

/**
 * Subclass of ship representing a cruiser (ship of length 3)
 *
 * @author Pablo Quinoa
 */
public class Cruiser extends Ship {
    
    /**
     * Constant representing the length of a battleship 
     */
    private static final int CRUISER_LENGTH = 3;

    /**
     * Constructs a new Cruiser and sets length of super class to 3
     */
    public Cruiser() {
        super(CRUISER_LENGTH);
    }

    /**
     * Returns the type of this ship (in this case cruiser)
     *
     * @return the type of ship
     */
    @Override
    public String getShipType() {
        return "Cruiser";
    }

    /**
     * Returns true, to ease development of classes for real ships
     *
     * @return wether is a real ship (empty sea would return false)
     */
    @Override
    public boolean isRealShip() {
        return true;
    }

}
