package Battleship;

import java.util.Random;

/**
 * Class to represent the Ocean of the Battleship game.
 *
 * @author Pablo Quinoa
 */
public class Ocean {

    /**
     * Constant representing the maximum value for a row (Ocean boundary [0..9])
     */
    private static final int MAX_ROW = 9;

    /**
     * Constant representing the maximum value for a column (Ocean boundary
     * [0..9])
     */
    private static final int MAX_COLUMN = 9;

    /**
     * Constant representing the total number of rows in Ocean
     */
    private static final int TOTAL_ROWS = 10;

    /**
     * Constant representing the total number of columns in Ocean
     */
    private static final int TOTAL_COLUMNS = 10;
    
    /**
     * Constant representing the number of ships initially displayed in Ocean
     */
    private static final int INITIAL_SHIPS_OCEAN = 10;

    /**
     * Array of ships used to quickly determine which ship is in any given
     * location. Is initialised as a matrix with 10 rows and 10 columns
     */
    private Ship[][] ships;

    /**
     * The total number of shots fired by the user
     */
    private int shotsFired;

    /**
     * The number of times a shot hit a ship. If the user shoots the same part
     * of a ship more than once, every hit is counted
     */
    private int hitCount;

    /**
     * The number of ships sunk (10 ships in total)
     */
    private int shipsSunk;

    /**
     * Constructs a new Ocean according to the parameters. Initializes the ships
     * array and sets all ships as EmptySea. Also initializes shotsFired,
     * hitCount and shipsSunk as 0.
     */
    public Ocean() {
        ships = new Ship[TOTAL_ROWS][TOTAL_COLUMNS];
        for (int row = 0; row <= MAX_ROW; row++) {
            for (int column = 0; column <= MAX_COLUMN; column++) {
                ships[row][column] = new EmptySea();
                ships[row][column].setBowRow(row);
                ships[row][column].setBowColumn(column);
                ships[row][column].setHorizontal(true);
            }
        }
        shotsFired = 0;
        hitCount = 0;
        shipsSunk = 0;
    }

    /**
     * Returns the 10x10 array of ships
     *
     * @return the array of Ships
     */
    public Ship[][] getShipArray() {
        return ships;
    }

    /**
     * Returns the number of shots fired.
     *
     * @return the number of shots fired
     */
    public int getShotsFired() {
        return shotsFired;
    }

    /**
     * Returns the number of hits recorded. All hits are counted, not just the
     * first time a given square is hit
     *
     * @return the number of hit shots
     */
    public int getHitCount() {
        return hitCount;
    }

    /**
     * Returns the number of ships sunk
     *
     * @return the number of ships sunk
     */
    public int getShipsSunk() {
        return shipsSunk;
    }

    /**
     * Returns true if all ships have been sunk, otherwise false
     *
     * @return whether game is over (all ships sunk)
     */
    public boolean isGameOver() {
        return getShipsSunk() == INITIAL_SHIPS_OCEAN;
    }

    /**
     * Returns true if the given location contains a ship, false if it does not
     *
     * @param row the row number
     * @param column the column number
     *
     * @return whether a given location is occupied by a ship
     */
    public boolean isOccupied(int row, int column) {
        //paremeter checking
        checkValidRowAndColumn (row, column);
        return ships[row][column].isRealShip();
    }

    /**
     * Returns true if the given location contains a sunk ship, false if it does
     * not
     *
     * @param row the row number
     * @param column the column number
     *
     * @return whether a given location has a sunk ship
     */
    public boolean hasSunkShipAt(int row, int column) {
        //paremeter checking
        checkValidRowAndColumn (row, column);
        return ships[row][column].isSunk();
    }

    /**
     * Returns the ship type at the given location
     *
     * @param row the row number
     * @param column the column number
     *
     * @return the type of ship at given location
     */
    public String getShipTypeAt(int row, int column) {
        //paremeter checking
        checkValidRowAndColumn (row, column);
        return ships[row][column].getShipType();
    }

    /**
     * Shoots at the part of the ship at that location. Returns true if the
     * given location contains a real ship (not an EmptySea), still afloat,
     * false if it does not. In addition, this method updates the number of
     * shots that have been fired, and the number of hits
     *
     * @param row the row number
     * @param column the column number
     *
     * @return whether the ship was succesfully hit (real ship not sunk)
     */
    public boolean shootAt(int row, int column) {
        //paremeter checking
        checkValidRowAndColumn (row, column);
        if (ships[row][column].isRealShip() && !ships[row][column].isSunk()) {
            ships[row][column].shootAt(row, column);
            shotsFired++;
            hitCount++;
            //sunk during this shoot
            if (ships[row][column].isSunk()) {
                shipsSunk++;
            }
            return true;
        } else {
            ships[row][column].shootAt(row, column);
            shotsFired++;
            return false;
        }
    }

    /**
     * Prints the ocean on stdout.
     */
    public void print() {
        System.out.println(" 0123456789");
        for (int row = 0; row <= MAX_ROW; row++) {
            System.out.print("\n" + row);
            for (int column = 0; column <= MAX_COLUMN; column++) {
                System.out.print(symbolToPrint(row, column));
            }
        }
    }

    /**
     * Returns the correspoding symbol for a given location in Ocean. Use "S" to
     * indicate a location that you have fired upon and hit a (real) ship, "-"
     * to indicate a location that you have fired upon and found nothing there,
     * "x" to indication a location containing a sunken ship, and "." to
     * indicate a location that you have never fired upon.
     *
     * @param row the row number
     * @param column the column number
     *
     * @return the corresponding symbol to the given Ocean location
     */
    private String symbolToPrint(int row, int column) {
        //paremeter checking
        checkValidRowAndColumn (row, column);
        String symbolPrint = new String();
        if (ships[row][column].isRealShip() && ships[row][column].getHit()[ships[row][column].partOfTheShip(row, column)] && !ships[row][column].isSunk()) {
            symbolPrint = "S";
        }
        if (!ships[row][column].isRealShip() && ships[row][column].getHit()[0]) {
            symbolPrint = "-";
        }
        if (ships[row][column].isSunk()) {
            symbolPrint = "x";
        }
        if (!ships[row][column].getHit()[ships[row][column].partOfTheShip(row, column)]) {
            symbolPrint = ".";
        }
        return symbolPrint;
    }

    /**
     * Places all ten ships randomly on the (initially empty) ocean. Places
     * larger ships before smaller ones.
     */
    public void placeAllShipsRandomly() {
        //generate and place 1 Battleship randomly
        Ship b1 = new Battleship();
        placeShipRandomly(b1);
        //generate and place 2 Cruisers randomly
        Ship c1 = new Cruiser();
        placeShipRandomly(c1);
        Ship c2 = new Cruiser();
        placeShipRandomly(c2);
        //generate and place 3 Destroyers randomly
        Ship d1 = new Destroyer();
        placeShipRandomly(d1);
        Ship d2 = new Destroyer();
        placeShipRandomly(d2);
        Ship d3 = new Destroyer();
        placeShipRandomly(d3);
        //generate and place 4 Submarines randomly
        Ship s1 = new Submarine();
        placeShipRandomly(s1);
        Ship s2 = new Submarine();
        placeShipRandomly(s2);
        Ship s3 = new Submarine();
        placeShipRandomly(s3);
        Ship s4 = new Submarine();
        placeShipRandomly(s4);
    }

    /**
     * Given a ship, it places the ship in a random location.
     *
     * @param Ship the row number
     */
    private void placeShipRandomly(Ship s) {
        //we look for a row/column random value
        Random rnd = new Random();
        int randomRow;
        int randomColumn;
        Boolean randomHorizontal;
        do {
            randomRow = rnd.nextInt(TOTAL_ROWS);
            randomColumn = rnd.nextInt(TOTAL_COLUMNS);
            randomHorizontal = rnd.nextBoolean();
        } while (!isAvailableToPlaceShip(randomRow, randomColumn, randomHorizontal, s.getLength()));
        s.setBowRow(randomRow);
        s.setBowColumn(randomColumn);
        s.setHorizontal(randomHorizontal);
        for (int i = 0; i < s.getLength(); i++) {
            if (s.isHorizontal()) {
                ships[randomRow][randomColumn + i] = s;
            } else {
                ships[randomRow + i][randomColumn] = s;
            }
        }
    }

    /**
     * Checks if a given Ocean location is available to place a ship. Checks
     * that the entire ship fits inside the 10x10 array, and also checks that
     * the given location has no adjacent ships.
     *
     * @param randomRow the row number generated by Random
     * @param randomColumn the column number generated by Random
     * @param randomHorizontal wether ship is horizontal/vertical postion
     * (Boolean value was generated by Random)
     * @param shipLength the length of the ship we want to place
     *
     * @return whether a given location is not occupied (and not adjacent to
     * occupied positions)
     */
    private Boolean isAvailableToPlaceShip(int randomRow, int randomColumn, Boolean randomHorizontal, int shipLength) {
        Boolean isAvailableToPlaceShip = true;
        for (int i = 0; i < shipLength; i++) {
            if (randomHorizontal) {
                randomColumn = randomColumn + i;
            } else {
                randomRow = randomRow + i;
            }
            if (randomRow > MAX_ROW || randomColumn > MAX_COLUMN) {
                isAvailableToPlaceShip = false;
                break;
            }
            if (!areAdjacentSquaresEmpty(randomRow, randomColumn)) {
                isAvailableToPlaceShip = false;
                break;
            }
        }
        return isAvailableToPlaceShip;
    }

    /**
     * Checks if all locations arround a given location are not occupied by real
     * ships
     *
     * @param randomRow the row number generated by Random
     * @param randomColumn the column number generated by Random
     *
     * @return whether a given location has all its adjacents empty
     */
    private Boolean areAdjacentSquaresEmpty(int randomRow, int randomColumn) {
        for (int dx = (randomRow > 0 ? -1 : 0); dx <= (randomRow < MAX_ROW ? 1 : 0); ++dx) {
            for (int dy = (randomColumn > 0 ? -1 : 0); dy <= (randomColumn < MAX_COLUMN ? 1 : 0); ++dy) {
                if (ships[randomRow + dx][randomColumn + dy].isRealShip()) {
                    return false;
                }
            }
        }
        return true;
    }
    
    /**
     * Checks if given row and column is inside the ocean boundaries [0..9]. If it is oustide, then
     * throws exception
     *
     * @param row the row number to be checked
     * @param column the column number to be checked
     */
    private void checkValidRowAndColumn (int row, int column){
        if (row<0 || row>MAX_ROW) {
            throw new IllegalArgumentException("Illegal negative argument or too big for a row value : "
                    + row);
        }
        if (column<0 || column>MAX_COLUMN) {
            throw new IllegalArgumentException("Illegal negative argument or too big for a column value : "
                    + column);
        }
    }

}
