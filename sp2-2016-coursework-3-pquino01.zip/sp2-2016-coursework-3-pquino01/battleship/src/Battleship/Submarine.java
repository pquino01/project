package Battleship;

/**
 * Subclass of ship representing a submarine (ship of length 1)
 *
 * @author Pablo Quinoa
 */
public class Submarine extends Ship {
    
     /**
     * Constant representing the length of a battleship 
     */
    private static final int SUBMARINE_LENGTH = 1;

    /**
     * Constructs a new Submarine and sets length of super class to 1
     */
    public Submarine() {
        super(SUBMARINE_LENGTH);
    }

    /**
     * Returns the type of this ship (in this case Submarine)
     *
     * @return the type of ship
     */
    @Override
    public String getShipType() {
        return "Submarine";
    }

    /**
     * Returns true, to ease development of classes for real ships
     *
     * @return wether is a real ship (empty sea would return false)
     */
    @Override
    public boolean isRealShip() {
        return true;
    }

}
