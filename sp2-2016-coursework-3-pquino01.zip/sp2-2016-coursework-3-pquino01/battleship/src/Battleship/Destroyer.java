package Battleship;

/**
 * Subclass of ship representing a destroyer (ship of length 2)
 *
 * @author Pablo Quinoa
 */
public class Destroyer extends Ship {
    
    /**
     * Constant representing the length of a battleship 
     */
    private static final int DESTROYER_LENGTH = 2;

    /**
     * Constructs a new Destroyer and sets length of super class to 2
     */
    public Destroyer() {
        super(DESTROYER_LENGTH);
    }

    /**
     * Returns the type of this ship (in this case destroyer)
     *
     * @return the type of ship
     */
    @Override
    public String getShipType() {
        return "Destroyer";
    }

    /**
     * Returns true, to ease development of classes for real ships
     *
     * @return wether is a real ship (empty sea would return false)
     */
    @Override
    public boolean isRealShip() {
        return true;
    }

}
