package Battleship;

/**
 * Abstract superclass to represent all kinds of Ships.
 *
 * @author Pablo Quinoa
 */
public abstract class Ship {
    
    /**
     * Constant representing the maximum length of a ship (in this case the length of the biggest ship, a battleship) 
     */
    private static final int MAX_LENGTH_SHIP = 4;
    
    /**
     * Constant representing the maximum value for a row (Ocean boundary [0..9])
     */
    private static final int MAX_ROW = 9;

    /**
     * Constant representing the maximum value for a column (Ocean boundary
     * [0..9])
     */
    private static final int MAX_COLUMN = 9;

    /**
     * The row (0 to 9) which contains the bow (front) of the ship.
     */
    private int bowRow;

    /**
     * the column (0 to 9) which contains the bow (front) of the ship
     */
    private int bowColumn;

    /**
     * The number of squares occupied by the ship. An “empty sea” location has
     * length 1.
     */
    private int length;

    /**
     * Set to true if the ship occupies a single row, false otherwise
     */
    private Boolean horizontal;

    /**
     * an array of booleans telling whether that part of the ship has been hit
     * (fired upon). Battleships use 4 locations; cruisers use 3; destroyers 2;
     * submarines and empty sea 1. Here hit[0] stands for the location at the
     * bow of the ship.
     */
    private Boolean[] hit;

    /**
     * Constructs a new Ship according to the parameters. Initializes the hit
     * array with false values.
     *
     * @param length the number of squares occupied by the ship
     */
    public Ship(int length) {
        if (length<0 || length>MAX_LENGTH_SHIP) {
            throw new IllegalArgumentException("Illegal negative argument or too big for Ship length : "
                    + length);
        }
        this.length = length;
        hit = new Boolean[length];
        for (int i = 0; i < length; i++) {
            hit[i] = false;
        }
    }

    /**
     * Returns the row which contains the bow/front of the ship
     *
     * @return row of the bow from the ship
     */
    public int getBowRow() {
        return bowRow;
    }

    /**
     * Registers the row where the front of the ship is
     *
     * @param bowRow the row number where the bow is
     */
    public void setBowRow(int bowRow) {
        this.bowRow = bowRow;
    }

    /**
     * Returns the column which contains the bow/front of the ship
     *
     * @return column of the bow from the ship
     */
    public int getBowColumn() {
        return bowColumn;
    }

    /**
     * Registers the column where the front of the ship is
     *
     * @param bowColumn the column number where the bow is
     */
    public void setBowColumn(int bowColumn) {
        this.bowColumn = bowColumn;
    }

    /**
     * Returns the length of the ship (number of squares occupied by ship)
     *
     * @return number of squares occupied by the ship
     */
    public int getLength() {
        return length;
    }

    /**
     * Returns wether the ship is in horizontal position
     *
     * @return true if the ship is in horizontal position, false otherwise
     */
    public Boolean isHorizontal() {
        return horizontal;
    }

    /**
     * Returns the array Hit, which stores wether each part of the ship was hit
     *
     * @return Hit array
     */
    public Boolean[] getHit() {
        return hit;
    }

    /**
     * Registers horizontal/vertical position of the ship
     *
     * @param horizontal wether the ship is horizontal or vertical position
     */
    public void setHorizontal(Boolean horizontal) {
        this.horizontal = horizontal;
    }

    /**
     * Returns the type of this ship
     *
     * @return the type of ship
     */
    public abstract String getShipType();

    /**
     * If a part of the ship occupies the given row and column, and the ship
     * hasn’t been sunk, mark that part of the ship as hit (in the hit array,
     * index 0 indicates the bow) and return true, otherwise return false
     *
     * @param row number to be shot
     * @param column number to be shot
     *
     * @return whether the ship was succesfully hit (real ship not sunk)
     */
    public boolean shootAt(int row, int column) {
        //paremeter checking
        checkValidRowAndColumn (row, column);
        if (isRealShip() && !isSunk()) {
            hit[partOfTheShip(row, column)] = true;
            return true;
        } else {
            if (!isRealShip()) {
                hit[0] = true;
            }
            return false;
        }
    }

    /**
     * Returns true, to ease development of classes for real ships
     *
     * @return wether is a real ship (empty sea would return false)
     */
    public abstract boolean isRealShip();

    /**
     * Returns true if every part of the ship has been hit, false otherwise
     *
     * @return wether every part of the ship has been hit or not
     */
    public boolean isSunk() {
        for (int i = 0; i < length; i++) {
            if (!hit[i]) {
                return false;
            }
        }
        return true;
    }

    /**
     * Returns which part of the Ship corredsponds to a given row/column (0
     * refers to bow). If the passed row/column does not correspond to any part
     * from the ship, -1 is returned.
     *
     * @param row number from the Ocean Array
     * @param column number from the Ocean Array
     *
     * @return which exact part of the ship corresponds to the given row/column
     */
    public int partOfTheShip(int row, int column) {
        //paremeter checking
        checkValidRowAndColumn (row, column);
        //if the row/column corresponds to the bow
        if (getBowRow() == row && getBowColumn() == column) {
            return 0;
        } else if (isHorizontal()) {
            return column - getBowColumn();
        } else {
            return row - getBowRow();
        }
    }
    
    /**
     * Checks if given row and column is inside the ocean boundaries [0..9]. If it is oustide, then
     * throws exception
     *
     * @param row the row number to be checked
     * @param column the column number to be checked
     */
    private void checkValidRowAndColumn (int row, int column){
        if (row<0 || row>MAX_ROW) {
            throw new IllegalArgumentException("Illegal negative argument or too big for a row value : "
                    + row);
        }
        if (column<0 || column>MAX_COLUMN) {
            throw new IllegalArgumentException("Illegal negative argument or too big for a column value : "
                    + column);
        }
    }
}
