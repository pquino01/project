package Battleship;

/**
 * Subclass of ship representing a battleship (ship of length 4)
 *
 * @author Pablo Quinoa
 */
public class Battleship extends Ship {
    
    /**
     * Constant representing the length of a battleship 
     */
    private static final int BATTLESHIP_LENGTH = 4;

    /**
     * Constructs a new Battleship and sets length of super class to 4
     */
    public Battleship() {
        super(BATTLESHIP_LENGTH);
    }

    /**
     * Returns the type of this ship (in this case battleship)
     *
     * @return the type of ship
     */
    @Override
    public String getShipType() {
        return "Battleship";
    }

    /**
     * Returns true, to ease development of classes for real ships
     *
     * @return wether is a real ship (empty sea would return false)
     */
    @Override
    public boolean isRealShip() {
        return true;
    }

}
