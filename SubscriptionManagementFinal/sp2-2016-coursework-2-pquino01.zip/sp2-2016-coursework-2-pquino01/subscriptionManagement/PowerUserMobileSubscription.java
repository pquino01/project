package subscriptionManagement;

/**
 * Mobile phone subscription with high standing charge, but low costs for used
 * services. Additionally has a "cost airbag", an upper bound for the charges
 * that can be incurred in a single billing period: only a bounded number of
 * call minutes and of text messages are charged, everything beyond that is
 * free. It also passes 4000 as standing fee to super.
 *
 * @author Pablo Quinoa
 */
public class PowerUserMobileSubscription extends MobileSubscription implements BoundedCharge {

    /**
     * Constant representing the price in pence of a minute call
     */
    private static int PENCEXMINUTECALL = 10;

    /**
     * Constant representing the price in pence of sending a text message
     */
    private static int PENCEXTEXTMESSAGE = 8;

    /**
     * Constant representing the maximum amount of minutes of calls they can
     * charge
     */
    private static int MAXMINUTES_CHARGED = 1800;

    /**
     * Constant representing the maximum amount of text messages they can charge
     */
    private static int MAXTEXTMESSAGES_CHARGED = 900;

    /**
     * Constant representing the standing charge for a power user mobile
     */
    private static int STANDINGCHARGE_PAYWHATYOUUSE = 4000;

    /**
     * Constructs a new PowerUserMobileSubscription according to the given
     * parameters. It also passes 4000p as standing fee to super.
     *
     * @param subscriber the name of the subscriber; must not be null
     * @param phoneNumber the phone number used for this subscription; must not
     * be null
     */
    public PowerUserMobileSubscription(String subscriber, String phoneNumber) {
        super(subscriber, "Mobile power user ".concat(phoneNumber), STANDINGCHARGE_PAYWHATYOUUSE);
    }

    /**
     * Returns the maximum total charge for a PowerUserMobileSubscription, that
     * is the same as the total charge for 1800 minutes of calls and 900 text
     * messages.
     *
     * @return the maximum total charge for a PowerUserMobileSubscription
     */
    @Override
    public int getMaxChargeInPence() {
        return calculateChargeAux(1800, 900);
    }

    /**
     * Returns the telephone number of the mobile. In this case, it removes
     * "Mobile power user " from the SuscriptionName to return only the phone
     * number.
     *
     * @return the telephone number of the mobile
     */
    @Override
    public String getPhoneNumber() {
        String phoneNum;
        phoneNum = super.getSubscriptionName();
        return phoneNum.substring(18);
    }

    /**
     * Returns the total charge for the services used in this billing period so
     * far. In the case of a PowerUserMobileSubscription, we charge 10
     * pence*(the minimum of 1800 or minutes spent) plus 8 pence*(the minimum of
     * 900 or the number of text messages sent, and finally plus a standing fee
     * of 4000 pence.
     *
     * @return the total charge for the services used in this billing period so
     * far
     */
    @Override
    public int computeTotalChargeInPence() {
        return calculateChargeAux(super.getCallMinutes(), super.getTextMessages());
    }

    /**
     * Returns the total charge for the services used in this billing period so
     * far. In the case of a PowerUserMobileSubscription, we charge 10
     * pence*(the minimum of 1800 or minutes spent) plus 8 pence*(the minimum of
     * 900 or the number of text messages sent, and finally plus a standing fee
     * of 4000 pence.
     *
     * @param minutes the number of call minutes spent
     * @param textMessages the number of textMessages sent
     *
     * @return the total charge for the services used in this billing period so
     * far
     */
    private int calculateChargeAux(int minutes, int textMessages) {
        int costMinutes;
        int costTextMessages;
        if (minutes < MAXMINUTES_CHARGED) {
            costMinutes = PENCEXMINUTECALL * minutes;
        } else {
            costMinutes = PENCEXMINUTECALL * MAXMINUTES_CHARGED;
        }
        if (textMessages < MAXTEXTMESSAGES_CHARGED) {
            costTextMessages = PENCEXTEXTMESSAGE * textMessages;
        } else {
            costTextMessages = PENCEXTEXTMESSAGE * MAXTEXTMESSAGES_CHARGED;
        }
        return (this.getStandingChargeInPence() + (costTextMessages + costMinutes));
    }

}
