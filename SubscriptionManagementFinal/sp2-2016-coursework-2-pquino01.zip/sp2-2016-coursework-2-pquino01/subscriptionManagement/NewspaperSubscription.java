package subscriptionManagement;

/**
 * A subscription to a newspaper or a magazine.
 *
 * @author Pablo Quinoa
 */
public class NewspaperSubscription extends Subscription implements HasAddress, BoundedCharge {

    /**
     * The adress where the newspaper is delivered.
     */
    private String address;

    /**
     * Constructs a new NewspaperSubscription based on the parameters.
     *
     * @param subscriber the name of the subscriber; must not be null
     * @param newspaper the name of the newspaper (and hence the subscription);
     * must not be null
     * @param standingChargeInPence the price of the newspaper per billing
     * period; must not be less than 0
     * @param address the address to which the newspaper is delivered; must not
     * be null
     */
    public NewspaperSubscription(String subscriber, String newspaper, int standingChargeInPence, String address) {
        super(subscriber, newspaper, standingChargeInPence);
        if (address == null) {
            throw new IllegalArgumentException("Illegal null argument for address.");
        }
        this.address = address;
    }

    /**
     * Returns the address from the suscriber of the newspaper.
     *
     * @return the address from the suscriber of the newspaper
     */
    @Override
    public String getAddress() {
        return address;
    }

    /**
     * Returns the maximum total charge for a NewspaperSubscription, that in
     * this case is the same as the standing charge.
     *
     * @return the maximum charge for a NewspaperSubscription
     */
    @Override
    public int getMaxChargeInPence() {
        return super.getStandingChargeInPence();
    }

    /**
     * Returns the total charge for the services used in this billing period so
     * far. In the case of a NewspaperSuscription, we charge the same amount as
     * the standing charge.
     *
     * @return the total charge for the services used in this billing period so
     * far
     */
    @Override
    public int computeTotalChargeInPence() {
        return super.getStandingChargeInPence();
    }

}
