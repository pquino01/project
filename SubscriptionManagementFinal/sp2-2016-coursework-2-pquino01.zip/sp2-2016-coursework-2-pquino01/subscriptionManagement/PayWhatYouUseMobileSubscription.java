package subscriptionManagement;

/**
 * Mobile phone subscription with zero standing charge, but high costs for used
 * services.
 *
 * @author Pablo Quinoa
 */
public class PayWhatYouUseMobileSubscription extends MobileSubscription {

    /**
     * Constant representing the price in pence of a minute call
     */
    private static int PENCEXMINUTECALL = 40;

    /**
     * Constant representing the price in pence of sending a text message
     */
    private static int PENCEXTEXTMESSAGE = 20;

    /**
     * Constant representing the standing charge for a pay what you use mobile
     */
    private static int STANDINGCHARGE_PAYWHATYOUUSE = 0;

    /**
     * Constructs a new PayWhatYouUseMobileSubscription according to the
     * parameters. It also passes 0 as standing fee to super.
     *
     * @param subscriber the name of the subscriber; must not be null
     * @param phoneNumber the phone number; must not be null
     */
    public PayWhatYouUseMobileSubscription(String subscriber, String phoneNumber) {
        super(subscriber, "Pay what you use mobile phone ".concat(phoneNumber), STANDINGCHARGE_PAYWHATYOUUSE);
    }

    /**
     * Returns the telephone number of the mobile. In this case, it removes "Pay
     * what you use mobile phone " from the SuscriptionName to return only the
     * phone number.
     *
     * @return the telephone number of the mobile
     */
    @Override
    public String getPhoneNumber() {
        String phoneNum;
        phoneNum = super.getSubscriptionName();
        return phoneNum.substring(30);
    }

    /**
     * Returns the total charge for the services used in this billing period so
     * far. In the case of a PayWhatYouUseMobileSubscription, we charge 40
     * pence*minute plus 20 pence*text message (and 0 standing fee).
     *
     * @return the total charge for the services used in this billing period so
     * far
     */
    @Override
    public int computeTotalChargeInPence() {
        return (PENCEXMINUTECALL * super.getCallMinutes()) + (PENCEXTEXTMESSAGE * super.getTextMessages());
    }

}
