package subscriptionManagement;

/**
 * Represents a phone subscription for landline telephones at a certain address.
 *
 * @author Pablo Quinoa
 */
public class LandlineSubscription extends PhoneSubscription implements HasAddress {

    /**
     * The adress where the landline is based.
     */
    private String address;

    /**
     * Constant representing the price in pence of a minute call
     */
    private static int PENCEXMINUTE = 2;

    /**
     * Constant representing the standing charge for a landline telephone
     */
    private static int STANDINGCHARGE_LANDLINES = 1800;

    /**
     * Constructs a new LandlineSubscription according to the parameters. For
     * the subscriptionName it concatenates "Landline Telephone " followed by
     * the telephone number passed. It also passes 1800 as standing fee to
     * super.
     *
     * @param subscriber the name of the subscriber; must not be null
     * @param phoneNumber the phone number; must not be null
     * @param address the address; must not be null
     */
    public LandlineSubscription(String subscriber, String phoneNumber, String address) {
        super(subscriber, "Landline Telephone ".concat(phoneNumber), STANDINGCHARGE_LANDLINES);
        if (address == null) {
            throw new IllegalArgumentException("Illegal null argument for address.");
        }
        this.address = address;
    }

    /**
     * Returns the total charge for the services used in this billing period so
     * far. In the case of a LandlineSubscription, we charge 2 pence*minute plus
     * a standing fee of 1800 pence.
     *
     * @return the total charge for the services used in this billing period so
     * far
     */
    @Override
    public int computeTotalChargeInPence() {
        return this.getStandingChargeInPence() + (PENCEXMINUTE * super.getCallMinutes());
    }

    /**
     * Returns the address of the landline phone.
     *
     * @return the address of the landline
     */
    @Override
    public String getAddress() {
        return address;
    }

    /**
     * Returns the telephone number of the landline. In this case, it removes
     * "Landline telephone " from the SuscriptionName to return only the phone
     * number.
     *
     * @return the telephone number of the landline
     */
    @Override
    public String getPhoneNumber() {
        String phoneNum;
        phoneNum = super.getSubscriptionName();
        return phoneNum.substring(19);
    }

}
