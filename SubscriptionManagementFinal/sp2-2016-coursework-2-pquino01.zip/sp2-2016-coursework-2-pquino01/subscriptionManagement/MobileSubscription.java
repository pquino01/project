package subscriptionManagement;

/**
 * Abstract superclass to represent subscriptions for mobile phones.
 *
 * @author Pablo Quinoa
 */
public abstract class MobileSubscription extends PhoneSubscription {

    /**
     * The amount of text messages registered for a Mobile Subscription.
     */
    private int textMessages;

    /**
     * Constructs a new MobileSubscription according to the parameters.
     *
     * @param subscriber the name of the subscriber; must not be null
     * @param phoneNumber the phone number; must not be null
     * @param standingChargeInPence the price of the mobile subscription per
     * billing period; must not be less than 0
     */
    public MobileSubscription(String subscriber, String phoneNumber, int standingChargeInPence) {
        super(subscriber, phoneNumber, standingChargeInPence);

    }

    /**
     * Registers the number of text messages sent. Here the parameter value
     * number must not be 0 or negative.
     *
     * @param number the number of text messages sent from a phone number; must
     * not be 0 or negative
     */
    public void sendTextMessages(int number) {
        if (number <= 0) {
            throw new IllegalArgumentException("Illegal negative or 0 argument for number of Text Messages: "
                    + number);
        }
        this.textMessages = this.textMessages + number;
    }

    /**
     * Returns the number of text messages sent since the last reset or initial
     * construct.
     *
     * @return the number of text messages sent since last reset or construct
     */
    public int getTextMessages() {
        return textMessages;
    }

    /**
     * Resets the minutes from calls and text messages made to 0.
     */
    @Override
    public void resetConsumption() {
        super.resetConsumption();
        this.textMessages = 0;
    }

}
