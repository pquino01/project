package subscriptionManagement;

/**
 * Abstract superclass for subscriptions to phone services.
 *
 * @author Pablo Quinoa
 */
public abstract class PhoneSubscription extends Subscription {

    /**
     * The amount of minutes registered for a Phone Subscription.
     */
    private int minutes;

    /**
     * Constructs a new PhoneSubscription according to the parameters.
     *
     * @param subscriber the name of the subscriber; must not be null
     * @param phoneNumber the phone number; must not be null
     * @param standingChargeInPence the price of the phone subscription per
     * billing period; must not be less than 0
     */
    public PhoneSubscription(String subscriber, String phoneNumber, int standingChargeInPence) {
        super(subscriber, phoneNumber, standingChargeInPence);

    }

    /**
     * Registers that a phone call of the given number of minutes was made. Here
     * the parameter value minutes must not be 0 or negative.
     *
     * @param minutes the number of minutes for a given phone call; must not be
     * 0 or negative
     */
    public void makeCall(int minutes) {
        if (minutes <= 0) {
            throw new IllegalArgumentException("Illegal negative or 0 argument for minutes: "
                    + minutes);
        }
        this.setCallMinutes(minutes);
    }

    /**
     * Returns the number of minutes of calls since the last reset or initial
     * construct.
     *
     * @return the number of minutes in calls since last reset or construct
     */
    public int getCallMinutes() {
        return minutes;
    }

    /**
     * Sets the amount of minutes of calls spent to the PhoneSubscription
     *
     * @param minutes the number of minutes to add to PhoneSubscription
     */
    public void setCallMinutes(int minutes) {
        this.minutes = this.minutes + minutes;
    }

    /**
     * Returns the description of the type of phone + phoneNumber.
     *
     * @return the type of phone followed by the phone number
     */
    public abstract String getPhoneNumber();

    /**
     * Resets the minutes from calls made to 0.
     */
    @Override
    public void resetConsumption() {
        this.minutes = 0;
    }

}
